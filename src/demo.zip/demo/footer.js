import React, {Component} from 'react';



export default class extends Component{
  constructor(props){
      super(props);
  }

  render(){

    let {
      leftItem,
      isShowClearButton,
      clearHasCompleted,
      view,
      changeView
    } = this.props;

    return (
      <footer className="footer">
        <span className="todo-count">
          <strong> {leftItem} </strong>
          <span>item left</span>
        </span>
        <ul className="filters">
          <li
            onClick={()=>changeView('all')}
          >
            <a
              className={view==='all'? 'selected' : ''}
            >All</a>

          </li>
          <li
            onClick={()=>changeView('active')}
          >
            <a
              className={view==='active'? 'selected' : ''}
            >Active</a>

          </li>
          <li
            onClick={()=>changeView('completed')}
          >
            <a
              className={view==='completed'? 'selected' : ''}
            >Completed</a>

          </li>
        </ul>
        {/* 清除完成按钮 */}
        {
          isShowClearButton && (
            <button
              className="clear-completed"
              onClick={clearHasCompleted}
            >
              clear all completed
            </button>
          )
        }

      </footer>
    )
  }
}
